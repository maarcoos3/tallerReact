import React from 'react';
import './descripcion.css'; // Opcional: si quieres añadir estilos

const Descripcion = () => {
  return (
    <div className="descripcion-container">
      <h2>Sobre Nosotros</h2>
      <p>
        Bienvenidos a Unique Football, la tienda en línea creada para los verdaderos apasionados del fútbol que buscan algo más que una camiseta. Nos especializamos en ofrecer productos exclusivos que combinan historia, estilo y autenticidad. 
        <br /> <br />
        En Unique Football, creemos que cada camiseta cuenta una historia. Por eso, ofrecemos una selección única de camisetas de fútbol retro que capturan los momentos más icónicos del deporte rey. Desde los clásicos de los años 70 y 80 hasta las leyendas más recientes, nuestras camisetas te permiten revivir la historia de los equipos y jugadores que han marcado épocas.
        Además, nos enorgullece ofrecer camisetas firmadas por los jugadores más grandes del fútbol, auténticas joyas para los coleccionistas y aficionados más exigentes. Cada pieza firmada viene con certificado de autenticidad, para que puedas tener la tranquilidad de que estás adquiriendo un artículo verdaderamente único.
        <br /> <br />
        Pero no solo nos detenemos ahí. En Unique Football, también trabajamos en colaboración con marcas de lujo para crear ediciones limitadas de camisetas que combinan el espíritu del fútbol con el diseño de alta gama. Estas colaboraciones elevan la experiencia del aficionado, llevando la pasión por el fútbol a un nivel completamente nuevo.
        Nuestra misión es ofrecerte productos que no encontrarás en ningún otro lugar. Ya seas un coleccionista o un amante del fútbol, Unique Football es el destino ideal para aquellos que buscan lo extraordinario.
      </p>
    </div>
  );
};

export default Descripcion;
